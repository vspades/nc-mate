from proc import *

try:		inp = argv[1]
except:	inp = ''

try:		out = 'squeezed_' + fname(inp)[0] + '_' + str(int(time())) + '.mp3'
except:	out = ''

cmd = 'ffmpeg -i "%s" -acodec libmp3lame -b:a 8k -ac 1 -ar 11025 "%s"' \
% (inp, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
