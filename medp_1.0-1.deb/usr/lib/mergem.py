from proc import *

try:
	l = listdir(argv[1])
	lst = []
	for i in l:
		lst.append(argv[1] + '/' + i)
except:	lst = ''

lst_f = 'list_' + str(random()) + '.txt'
fh = open(lst_f, 'w')
for i in lst:	fh.write("file '" + i + "'\n")
fh.close()

try:		ext = fname(lst[0])[1]
except:	ext = 'mp4'

try:		out = '_merged_' + str(int(time())) + '.%s' % (ext)
except:	pass

cmd = 'ffmpeg -f concat -safe 0 -i "%s" -c copy "%s"' % (lst_f, out)
pid = s(cmd + ' -y 2> /dev/null')
s('rm ' + lst_f + ' 2>/dev/null')
if pid != 0:
	print '[ FAILED ]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
