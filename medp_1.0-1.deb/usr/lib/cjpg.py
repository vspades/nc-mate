from proc import *

try:		inp = argv[1]
except:	inp = ''

try:		q = argv[2]
except:	q = ''

try:		copyfile(inp, 'backup_' + fname(inp)[0] + '.' + fname(inp)[1])
except:	pass

cmd = 'jpegoptim -q --max="%s" "%s"' % (q, inp)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + '"backup_' + fname(inp)[0] + '.' + fname(inp)[1] + '" 2>/dev/null')
else:
		pass
