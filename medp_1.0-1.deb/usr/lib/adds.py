from proc import *

try:		sub = argv[1]
except:	sub = ''

try:		inp = argv[2]
except:	inp = ''

try:		ass = fname(sub)[0] + '.ass'
except:	ass = ''

cmd = 'ffmpeg -i "%s" "%s"' % (sub, ass)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:	print '[FAILED]:', cmd
else:					print '[OK]:', cmd

try:		out = 'sub_' + fname(inp)[0] + '_' + str(int(time())) + '.mp4'
except:	out = ''

cmd = \
'ffmpeg -i "%s" -strict experimental -c:a aac -async 1 -vf ass="%s" "%s"' \
% (inp, ass, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:	print '[FAILED]:', cmd
else:					print '[OK]:', cmd

cmd = 'rm *.ass 2>/dev/null'
pid = s(cmd + ' 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd

#sample.SRT
#1
#00:00:02,000 --> 00:00:08,000
#this line stays here for 6 seconds.

#2
#00:00:10,000 --> 00:00:15,000
#this one remains for 5 seconds.
