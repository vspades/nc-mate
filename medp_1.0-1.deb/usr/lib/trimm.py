from proc import *

try:		inp = argv[1]
except:	inp = ''

try:		out = 'trimmed_' + fname(argv[1])[0] + '_' + str(int(time())) + '.mp4'
except:	out = ''

try:		t1 = argv[2]
except:	t1 = ''

try:		t2 = argv[3]
except:	t2 = ''

cmd = \
'ffmpeg -i "%s" -strict experimental -c:a aac -async 1 -ss "%s" -to "%s" "%s"' \
% (inp, t1, t2, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
