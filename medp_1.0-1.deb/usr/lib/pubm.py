from proc import *

def pub():
	v='''<video controls width='640' length='320'>
	<source src="%s">
</video>''' % (out)
	s("echo '" + v + "' > '" + wout + "'")

try:		inp = argv[1]
except:	inp = ''

try:		out = 'pub_' + fname(inp)[0] + '_' + str(int(time())) + '.mp4'
except:	out = ''

try:		wout = 'pub_' + fname(inp)[0] + '_' + str(int(time())) + '.htm'
except:	wout = ''

cmd = 'ffmpeg -i "%s" -strict experimental -c:a aac -async 1 "%s"' % (inp, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:	print '[FAILED]:', cmd
else:
	print '[OK]:', cmd
	pub()
