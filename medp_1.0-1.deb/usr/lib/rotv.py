from proc import *

try:		inp = argv[1]
except:	inp = ''

try:		rot = argv[2]
except:	rot = ''

out = 'rot_' + fname(inp)[0] + '_' + str(int(time())) + '.mp4'

if		rot == '--right':					rot = 'transpose=1'
elif	rot == '--left':					rot = 'transpose=2'
elif	rot == '--flip':					rot = 'transpose=0, transpose=1'
elif	rot == '--up-side-down':	rot = 'transpose=1, transpose=1'
else:	pass

cmd = 'ffmpeg -i "%s" -vf "%s" -c:a aac -strict -2 "%s"' % (inp, rot, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
