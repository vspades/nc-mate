from proc import *

try:		inp = argv[1]
except:	inp = ''

s("ffmpeg -i '" + inp + "' 2>&1 | grep -oP 'Stream .*, \K[0-9]+x[0-9]+'")

try:		dim = argv[2]
except:	dim = ''

try:		out = 'crop_' + fname(inp)[0] + '_' + str(int(time())) + '.mp4'
except:	out = ''

try:
	x = dim.split(':')[0]
	y = dim.split(':')[1]
	w = dim.split(':')[2]
	h = dim.split(':')[3]
except:
	pass

try:		crop = w + ':' + h + ':' + x + ':' + y
except:	crop = 'w:h:x:y'
cmd = 'ffmpeg -i "%s" -filter:v "crop=%s" -c:a aac -strict -2 "%s"' \
% (inp, crop, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
