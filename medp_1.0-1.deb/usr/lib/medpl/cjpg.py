from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp cjpg --help'
	exit()
if argv[1] == '--help':
	print 'compresses JPEG (JPG) image.'
	print ''
	print '-----------------------------------------------------'
	print '[PATTERN] medp cjpg <inp-img> [<quality>(default=10)]'
	print '-----------------------------------------------------'
	print 'degrades quality of <inp-img>(.jpg|.jpeg).'
	exit()
inp = argv[1]
q = argv[2]
if q == '':	q = 10
# defines output JPG file.
out = 'backup_' + uri(inp)[3] + uri(inp)[4]
# backs up the original JPG file.
try:
	system('echo -n "[1] making back-up of original JPEG image..."')
	copyfile(inp, out)
	print 'done.'
except:
	print '\n[FAILED] no such a file or directory.'
	exit()
cmd = 'jpegoptim -q --max="%s" "%s"' % (q, inp)
system('echo -n "[2] compressing JPEG <inp-img>..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	pid = system('sudo ' + cmd + ' -y 2>/dev/null')
	if pid != 0:
		print '\n[FAILED]', cmd
		system('rm "' + out + '" 2>/dev/null')
		exit()
print '\n[OK] JPEG image lost its quality.'
