from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp mergem --help'
	exit()
if argv[1] == '--help':
	print 'merges multiple media-files into one.'
	print ''
	print '-----------------------------------'
	print '[PATTERN] medp mergem <path-to-dir>'
	print '-----------------------------------'
	print 'merges multiple media-files inside a folder into one whole file.'
	print 'files\' format need to be the same. or else, it\'d return by error.'
	print '[example] medp mergem <my-dir>'
	print 'all files inside <my-dir> must be of the same format (ex. 3gpp),'
	print 'same resolution, ... . otherwise, the result might be unexpected.'
	exit()
d = argv[1] + '/'
try:
	l = listdir(d)
	l.sort()
except:
	print '[FAILED] no such directory.'
	exit()
lst = []
for i in l:	lst.append(d + '/' + i)
lst_f = 'list_' + str(int(time())) + '.txt'
fh = open(lst_f, 'w')
for i in lst:	fh.write("file '" + i + "'\n")
fh.close()
ext = uri(l[0])[4]
out = 'merged_' + str(int(time())) + '%s' % (ext)
cmd = 'ffmpeg -f concat -safe 0 -i "%s" -c copy "%s"' % (lst_f, out)
system('echo -n "[1] merging <media-files>..."')
pid = system(cmd + ' -y 2> /dev/null')
system('rm ' + lst_f + ' 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] media-files merged into one.'
