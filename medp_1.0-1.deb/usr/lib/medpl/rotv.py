from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp rotv --help'
	exit()
if argv[1] == '--help':
	print 'rotates video.'
	print ''
	print '---------------------------------------------------------'
	print '[PATTERN] medp rotv <inp-vid> [<direction>(default=left)]'
	print '---------------------------------------------------------'
	print 'rotates video to the specified direction. directions could be:'
	print '\tright'
	print '\tleft'
	print '\tflip'
	print '\tup-side-down'
	print '[example] medp rotv "inp.avi" left'
	print 'rotates <inp.avi> video counter-clockwise.'
	exit()
#
inp = argv[1]
rot = argv[2]
if rot == '':	rot = 'left'
#
out = 'rot_' + uri(inp)[3] + '_' + str(int(time())) + '.mp4'
if rot == 'right':				rot = 'transpose=1'
if rot == 'left':					rot = 'transpose=2'
if rot == 'flip':					rot = 'transpose=0, transpose=1'
if rot == 'up-side-down':	rot = 'transpose=1, transpose=1'
#
cmd = 'ffmpeg -i "%s" -vf "%s" -c:a aac -strict -2 "%s"' % (inp, rot, out)
system('echo -n "[1] rotating video..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] video is rotated.'
