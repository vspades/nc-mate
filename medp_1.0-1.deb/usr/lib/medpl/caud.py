from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp caud --help'
	exit()
if argv[1] == '--help':
	print 'extracts sound from video.'
	print ''
	print '-----------------------------'
	print '[PATTERN] medp caud <inp-vid>'
	print '-----------------------------'
	print 'converts <inp-vid> to an audio-file(.mp3).'
	exit()
inp = argv[1]
out = 'sound_' + uri(inp)[3] + '_' + str(int(time())) + '.mp3'
system('echo -n "[1] extracting sound from <inp-vid>..."')
cmd = 'ffmpeg -i "%s" "%s"'	% (inp, out)
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] sound extracted from video.'
