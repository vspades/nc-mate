from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp adds --help'
	exit()
if argv[1] == '--help':
	print 'adds subtitles to video.'
	print ''
	print '---------------------------------------'
	print '[PATTERN] medp adds <sub.srt> <inp-vid>'
	print '---------------------------------------'
	print 'adds <sub.srt> to <inp-vid>.'
	exit()
sub = argv[1]
inp = argv[2]
ass = uri(sub)[3] + '.ass'
system('echo -n "[1] converting <.srt> to <.ass>..."')
cmd = 'ffmpeg -i "%s" "%s"' % (sub, ass)
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	exit()
else:	print 'done.'
# defines output file's name.
out = 'sub_' + uri(inp)[3] + '_' + str(int(time())) + '.mp4'
# adds sub-file to vid-file.
system('echo -n "[2] adding <sub.srt> to <inp-vid>..."')
cmd = \
'ffmpeg -i "%s" -strict experimental -c:a aac -async 1 -vf ass="%s" "%s"' \
% (inp, ass, out)
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	system('echo -n "[3] cleaning area..."')
	cmd = 'rm ' + ass
	pid = system(cmd + ' 2>/dev/null')
	print 'done.'
	exit()
else:	print 'done.'
system('echo -n "[3] cleaning area..."')
cmd = 'rm ' + ass
pid = system(cmd + ' 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] subtitles added to video.'
