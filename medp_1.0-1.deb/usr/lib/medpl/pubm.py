from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp pubm --help'
	exit()
if argv[1] == '--help':
	print 'prepares a media-file to publish on the web.'
	print ''
	print '-----------------------------'
	print '[PATTERN] medp pubm <inp-med>'
	print '-----------------------------'
	print 'generates an HTM output with the video (already converted to .mp4),'
	print 'embedded inside.'
	exit()
# prepares HTM output.
def pub():
	v='''<video controls width='640' length='320'>
	<source src="%s">
</video>''' % (out)
	system("echo '" + v + "' > '" + wout + "'")
#
inp = argv[1]
out = 'pub_' + uri(inp)[3] + '_' + str(int(time())) + '.mp4'
wout = 'pub_' + uri(inp)[3] + '_' + str(int(time())) + '.htm'
cmd = 'ffmpeg -i "%s" -strict experimental -c:a aac -async 1 "%s"' % (inp, out)
system('echo -n "[1] preparing media to publish..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:	print '\n[FAILED]:', cmd
else:
	print 'done.'
	print '[OK] an HTM output with the media embedded is prepared.'
	pub()
