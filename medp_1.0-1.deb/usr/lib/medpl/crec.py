from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp crec --help'
	exit()
if argv[1] == '--help':
	print 'excludes wind-noise from recorded meeting-voice.'
	print ''
	print '-----------------------------'
	print '[PATTERN] medp crec <inp-aud>'
	print '-----------------------------'
	print 'degrades quality of <inp-aud>.'
	exit()
inp = argv[1]
out = 'squeezed_' + uri(inp)[3] + '_' + str(int(time())) + '.mp3'
cmd = 'ffmpeg -i "%s" -acodec libmp3lame -b:a 8k -ac 1 -ar 11025 "%s"' \
% (inp, out)
system('echo -n "[1] squeezing <inp-aud>..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]:', cmd
	system('rm ' + out + ' 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] audio squeezed.'
