from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp cropv --help'
	exit()
if argv[1] == '--help':
	print 'crops video.'
	print ''
	print '------------------------------'
	print '[PATTERN] medp cropv <inp-vid>'
	print '------------------------------'
	print 'tells <inp-vid>\'s aspect-ratio and fails.'
	print ''
	print '------------------------------------'
	print '[PATTERN] medp cropv <inp-vid> <dim>'
	print '------------------------------------'
	print 'crops <inp-vid> in specified dimensions.'
	print '<dim>-format = x:y:w:h --'
	print '\tx: x-start-point of cropped-box'
	print '\ty: y-start-point of cropped-box'
	print '\tw: width of cropped-box'
	print '\th: height of cropped-box'
	print '[example] medp cropv "inp.avi" 0:0:32:24'
	print 'crops the <inp.avi> video by size of <width=32, height=24> started'
	print 'from <x=0, y=0> of the video-frame\'s top-left.'
	exit()
inp = argv[1]
system('echo -n "[1] video\'s aspect ratio: "')
pid = system(
"ffmpeg -i '" + inp + "' 2>&1 | grep -oP 'Stream .*, \K[0-9]+x[0-9]+'")
if pid != 0:
	print '\n[FAILED] not able to elicit video\'s resolution.'
	exit()
dim = argv[2]
out = 'crop_' + uri(inp)[3] + '_' + str(int(time())) + '.mp4'
try:
	x = dim.split(':')[0]
	y = dim.split(':')[1]
	w = dim.split(':')[2]
	h = dim.split(':')[3]
	crop = w + ':' + h + ':' + x + ':' + y
except:	crop = 'w:h:x:y'
cmd = 'ffmpeg -i "%s" -filter:v "crop=%s" -c:a aac -strict -2 "%s"' \
% (inp, crop, out)
system('echo -n "[2] cropping <inp-vid>..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]:', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] video is cropped.'
