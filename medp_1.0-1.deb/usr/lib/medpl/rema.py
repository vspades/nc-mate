from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp rema --help'
	exit()
if argv[1] == '--help':
	print 'mutes video.'
	print ''
	print '-----------------------------'
	print '[PATTERN] medp rema <inp-vid>'
	print '-----------------------------'
	print '<inp-vid> with no sound.'
	exit()
inp = argv[1]
out = 'muted_' + uri(argv[1])[3] + '_' + str(int(time())) + uri(argv[1])[4]
cmd = 'ffmpeg -i "%s" -c copy -an "%s"' % (inp, out)
system('echo -n "[1] muting <inp-vid>..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED]', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] video is muted.'
