from func import *
if argv[1] == '':
	print '[FAILED] no argument(s) supplied.'
	print 'medp trimm --help'
	exit()
if argv[1] == '--help':
	print 'trims media-file.'
	print ''
	print '---------------------------------------------'
	print '[PATTERN] medp trimm <inp-med> <start> <stop>'
	print '---------------------------------------------'
	print 'trims <inp-med> from specified <start>-time up to <stop>-time.'
	print '[example] medp trimm "inp.avi" 2:40 4:05.10'
	print 'trims the <inp.avi> video'
	print 'from <2-min and 40-sec>'
	print 'to <4-min and 5-sec and 10-msec>.'
	exit()
inp = argv[1]
out = 'trimmed_' + uri(inp)[3] + '_' + str(int(time())) + '.mp4'
t1 = argv[2]
t2 = argv[3]
cmd = \
'ffmpeg -i "%s" -strict experimental -c:a aac -async 1 -ss "%s" -to "%s" "%s"' \
% (inp, t1, t2, out)
system('echo -n "[1] trimming <inp-med>..."')
pid = system(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '\n[FAILED] ', cmd
	system('rm "' + out + '" 2>/dev/null')
	exit()
else:	print 'done.'
print '[OK] media is trimmed.'
