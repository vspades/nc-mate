from proc import *

try:		inp = argv[1]
except:	inp = ''

try:		out = 'muted_' + fname(argv[1])[0] + '_' + str(int(time())) + '.' + \
fname(argv[1])[1]
except:	out = ''

cmd = 'ffmpeg -i "%s" -c copy -an "%s"' % (inp, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
