from proc import *

try:		inp = argv[1]
except:	inp = ''

s("ffmpeg -i '" + inp + "' 2>&1 | grep -oP 'Stream .*, \K[0-9]+x[0-9]+'")

try:		dim = argv[2]
except:	dim = ''

try:		col = argv[3]
except:	col = 'black'

try:		out = 'cen_' + fname(inp)[0] + '_' + str(int(time())) + '.mp4'
except:	out = ''

try:
	x = dim.split(':')[0]
	y = dim.split(':')[1]
	w = dim.split(':')[2]
	h = dim.split(':')[3]
except:
	pass

try:		box = 'drawbox=x=' + x + ':y=' + y + ':w=' + w + ':h=' + h \
				+ ':color=' + col + '@1:t=max'
except:	box = 'drawbox=x=X:y=Y:w=W:h=H:color=white@1:t=max'

cmd = 'ffmpeg -i "%s" -vf "%s" -strict -2 "%s" -y' % (inp, box, out)
pid = s(cmd + ' -y 2>/dev/null')
if pid != 0:
	print '[FAILED]:', cmd
	s('rm ' + out + ' 2>/dev/null')
else:
	print '[OK]:', cmd
